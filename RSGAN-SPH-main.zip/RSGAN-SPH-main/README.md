# RSGAN-SPH
A fork of QRec (https://github.com/Coder-Yu/QRec) implementing RSGAN-SPH, an improvement of RSGAN

<p float="left"><img src="https://img.shields.io/badge/python-v2.7.8-red"> <img src="https://img.shields.io/badge/tensorflow-v1.14+-blue"> <img alt="GitHub last commit" src="https://img.shields.io/github/last-commit/Coder-Yu/QRec"></p>

* run_rsgan.ipnyb is a script for running the code in a python2.7 Google Collab environment. Change the file paths inside to accomodate your file hierarchies.
